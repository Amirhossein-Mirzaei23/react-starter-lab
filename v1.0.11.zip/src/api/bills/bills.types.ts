export interface BillDto {
  userId: number;
  id: number;
  title: string;
  body: string;
}
