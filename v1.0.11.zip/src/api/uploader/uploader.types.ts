export interface updaloerResponse {
  message: string;
  filePath: string;
  filename: string;
  size: string;
  fullURL: string;
}
